function goodNoteHit(id, dir, type, sustain)
    if getPropertyFromGroup('notes', id, 'rating') == 'sick' then
        local index = dir + 4
        local y = getPropertyFromGroup('strumLineNotes', index, 'y')

        -- podskok
        setPropertyFromGroup('strumLineNotes', index, 'y', y - 14)

        -- zapamiętujemy oryginalne Y
        setProperty('bounceY'..index, y)

        -- wróci po 0.7 sekundy
        runTimer('bounceBack'..index, 0.7, 1)
    end
end

function onTimerCompleted(tag)
    if string.sub(tag, 1, 10) == 'bounceBack' then
        local index = tonumber(string.sub(tag, 11))
        local y = getProperty('bounceY'..index)

        -- powrót na miejsce
        setPropertyFromGroup('strumLineNotes', index, 'y', y)
    end
end

