Put your songs here, it should look like this:

assets/songs/your-song-name-here/
---- ./Inst.ogg
---- ./Voices.ogg