function onEvent(name, v1, v2)
    if name == "FlashScreen" then
        local color = v1 or "FFFFFF"
        local duration = tonumber(v2) or 0.5

        -- Tworzymy czarny/kolorowy prostokąt na ekranie
        makeLuaSprite("flashScreen", nil, 0, 0)
        makeGraphic("flashScreen", screenWidth, screenHeight, color)
        setObjectCamera("flashScreen", "other")
        addLuaSprite("flashScreen", true)

        -- Fade-out
        doTweenAlpha("flashFade", "flashScreen", 0, duration, "linear")
    end
end

function onTweenCompleted(tag)
    if tag == "flashFade" then
        removeLuaSprite("flashScreen", true)
    end
end
