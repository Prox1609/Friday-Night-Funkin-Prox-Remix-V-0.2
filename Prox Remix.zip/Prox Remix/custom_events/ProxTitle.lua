function onEvent(name, v1, v2)
    if name ~= "ProxTitle" then return end

    local title = v1 .. " remix by Prox"
    local czas = tonumber(v2) or 3

    -- Tekst
    makeLuaText("proxTitle", title, 1280, 0, 300)
    setTextSize("proxTitle", 54)
    setTextAlignment("proxTitle", "center")
    setObjectCamera("proxTitle", "other")
    setTextColor("proxTitle", "00C8FF") -- galaktyczny niebieski
    addLuaText("proxTitle")

    -- Start: niewidoczny
    setProperty("proxTitle.alpha", 0)

    -- MOCNY glitch wejścia (bez obrotów)
    doTweenAlpha("proxIn", "proxTitle", 1, 0.10, "linear")
    doTweenX("proxGlitch1", "proxTitle", getProperty("proxTitle.x") + 40, 0.04, "linear")
    doTweenX("proxGlitch2", "proxTitle", getProperty("proxTitle.x") - 40, 0.04, "linear")

    runTimer("proxHold", czas)
end

function onTimerCompleted(tag)
    if tag == "proxHold" then
        -- MOCNY glitch wyjścia
        doTweenAlpha("proxOut", "proxTitle", 0, 0.10, "linear")
        doTweenX("proxGlitch3", "proxTitle", getProperty("proxTitle.x") + 45, 0.04, "linear")
        doTweenX("proxGlitch4", "proxTitle", getProperty("proxTitle.x") - 45, 0.04, "linear")
    end
end
