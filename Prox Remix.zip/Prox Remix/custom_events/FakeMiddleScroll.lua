local savedPlayerX = {}
local savedOpponentX = {}
local savedOpponentAlpha = {}
local positionsSaved = false

function onCreatePost()
    -- zapisujemy oryginalne pozycje strzałek gracza i przeciwnika
    for i = 0, 3 do
        savedPlayerX[i] = getPropertyFromGroup('playerStrums', i, 'x')
        savedOpponentX[i] = getPropertyFromGroup('opponentStrums', i, 'x')
        savedOpponentAlpha[i] = getPropertyFromGroup('opponentStrums', i, 'alpha')
    end
    positionsSaved = true
end

function onEvent(name, v1, v2)
    if name ~= 'FakeMiddleScroll' then return end
    if not positionsSaved then return end

    local toggle = tonumber(v1) or 1
    local time = tonumber(v2) or 0.4  -- czas animacji (domyślnie 0.4s)

    if toggle == 1 then
        -- ŚRODEK: animacja przesuwania player strums
        local baseX = 412
        local offset = 112

        for i = 0, 3 do
            doTweenX("playerToMiddle"..i, "playerStrums.members["..i.."]", baseX + (i * offset), time, "quadInOut")
        end

        -- chowamy strzałki przeciwnika animacją
        for i = 0, 3 do
            doTweenAlpha("oppHide"..i, "opponentStrums.members["..i.."]", 0, time, "quadInOut")
            setPropertyFromGroup('opponentStrums', i, 'visible', false)
        end

    else
        -- POWRÓT: animacja powrotu player strums
        for i = 0, 3 do
            doTweenX("playerBack"..i, "playerStrums.members["..i.."]", savedPlayerX[i], time, "quadInOut")
        end

        -- przywracamy strzałki przeciwnika animacją
        for i = 0, 3 do
            setPropertyFromGroup('opponentStrums', i, 'visible', true)
            doTweenAlpha("oppShow"..i, "opponentStrums.members["..i.."]", savedOpponentAlpha[i], time, "quadInOut")
            doTweenX("oppBack"..i, "opponentStrums.members["..i.."]", savedOpponentX[i], time, "quadInOut")
        end
    end
end
