function onEvent(name, v1, v2)
    if name == "MiddleScrollToggle" then
        local toggle = tonumber(v1) or 1

        if toggle == 1 then
            -- Włącz middlescroll
            setPropertyFromClass('ClientPrefs', 'middleScroll', true)
            setPropertyFromClass('ClientPrefs', 'opponentStrums', false)
        else
            -- Wyłącz middlescroll
            setPropertyFromClass('ClientPrefs', 'middleScroll', false)
            setPropertyFromClass('ClientPrefs', 'opponentStrums', true)
        end

        -- Odświeżenie strzałek
        reloadNotes()
    end
end
