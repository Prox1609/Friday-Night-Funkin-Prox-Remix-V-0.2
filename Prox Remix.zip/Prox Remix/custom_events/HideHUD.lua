function onEvent(name, v1, v2)
    if name == "HideHUD" then
        local hide = tonumber(v1) or 1

        if hide == 1 then
            -- Hide HUD
            setProperty('camHUD.alpha', 0)
        else
            -- Show HUD
            setProperty('camHUD.alpha', 1)
        end
    end
end
