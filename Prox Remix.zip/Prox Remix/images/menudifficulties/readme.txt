Drop your custom difficulty image here!

For more info, go here:
https://github.com/ShadowMario/FNF-PsychEngine/wiki/Adding-a-New-Difficulty